import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { Search, TrendingUp } from 'lucide-react-native';

export default function HomeScreen() {
  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.greeting}>Welcome back, User!</Text>
        <TouchableOpacity style={styles.searchButton}>
          <Search size={20} color="#666" />
          <Text style={styles.searchText}>Search courses or jobs...</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Recommended Courses</Text>
          <TrendingUp size={20} color="#4285f4" />
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Your Progress</Text>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Job Matches</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    padding: 20,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e5e5e5',
  },
  greeting: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#1a1a1a',
    marginBottom: 16,
  },
  searchButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f0f0f0',
    padding: 12,
    borderRadius: 8,
  },
  searchText: {
    marginLeft: 8,
    color: '#666',
    fontFamily: 'Inter-Regular',
  },
  section: {
    padding: 20,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#1a1a1a',
  },
});